#ifndef QTIPCSERVER_H
#define QTIPCSERVER_H

// Define Paycoin-Qt message queue name
#define BITCOINURI_QUEUE_NAME "PaycoinURI"

void ipcInit();
void ipcShutdown();

#endif // QTIPCSERVER_H
