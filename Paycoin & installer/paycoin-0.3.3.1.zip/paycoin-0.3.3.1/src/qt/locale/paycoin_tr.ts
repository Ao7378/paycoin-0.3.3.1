<TS language="tr" version="2.0">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>AboutDialog</name>
    </context>
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Address Book</source>
        <translation>Adres defteri</translation>
    </message>
    <message>
        <source>Double-click to edit address or label</source>
        <translation>Adresi ya da etiketi düzenlemek için çift tıklayınız</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Yeni bir adres oluştur</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Şu anda seçili olan adresi panoya kopyalar</translation>
    </message>
    <message>
        <source>Show &amp;QR Code</source>
        <translation>&amp;QR kodunu göster</translation>
    </message>
    <message>
        <source>Sign a message to prove you own this address</source>
        <translation>Bu adresin sizin olduğunu ispatlamak için mesaj imzalayın</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>Mesaj &amp;imzala</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list. Only sending addresses can be deleted.</source>
        <translation>Seçilen adresi listeden siler. Sadece gönderi adresleri silinebilir.</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Sil</translation>
    </message>
    <message>
        <source>Export Address Book Data</source>
        <translation>Adres defteri verilerini dışa aktar</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Virgülle ayrılmış değerler dosyası (*.csv)</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Dışa aktarımda hata oluştu</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>%1 dosyasına yazılamadı.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Etiket</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adres</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(boş etiket)</translation>
    </message>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Enter passphrase</source>
        <translation>Parolayı giriniz</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Yeni parola</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Yeni parolayı tekrarlayınız</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Cüzdanınız için yeni parolayı giriniz.&lt;br/&gt;Lütfen &lt;b&gt;10 ya da daha fazla rastgele karakter&lt;/b&gt; veya &lt;b&gt;sekiz ya da daha fazla kelime&lt;/b&gt; içeren bir parola seçiniz.</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Cüzdanı şifrele</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Bu işlem cüzdan kilidini açmak için cüzdan parolanızı gerektirir.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Cüzdan kilidini aç</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Bu işlem, cüzdan şifresini açmak için cüzdan parolasını gerektirir.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Cüzdan şifresini aç</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Parolayı değiştir</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Cüzdan şifrelenmesini teyit eder</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Cüzdan şifrelendi</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on.</source>
        <translation>Uyarı: Caps Lock tuşu etkin durumda.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Cüzdan şifrelemesi başarısız oldu</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Dahili bir hata sebebiyle cüzdan şifrelemesi başarısız oldu. Cüzdanınız şifrelenmedi.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>Girilen parolalar birbirleriyle uyumlu değil.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Cüzdan kilidinin açılması başarısız oldu</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Cüzdan şifresinin açılması için girilen parola yanlıştı.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Cüzdan şifresinin açılması başarısız oldu</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Cüzdan parolası başarılı bir şekilde değiştirildi.</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Amount:</source>
        <translation>Miktar:</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Miktar</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adres</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Tarih</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Doğrulandı</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Adresi kopyala</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Etiketi kopyala</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Miktarı kopyala</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(boş etiket)</translation>
    </message>
    </context>
<context>
    <name>DisplayOptionsPage</name>
    <message>
        <source>&amp;Unit to show amounts in: </source>
        <translation>Miktarı göstermek için &amp;birim: </translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface, and when sending coins</source>
        <translation>Para (coin) gönderildiğinde arayüzde gösterilecek varsayılan alt birimi seçiniz</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Adresi düzenle</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Etiket</translation>
    </message>
    <message>
        <source>The label associated with this address book entry</source>
        <translation>Bu adres defteri unsuru ile ilişkili etiket</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Adres</translation>
    </message>
    <message>
        <source>The address associated with this address book entry. This can only be modified for sending addresses.</source>
        <translation>Bu adres defteri unsuru ile ilişkili adres. Bu, sadece gönderi adresi için değiştirilebilir.</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Yeni alım adresi</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Yeni gönderi adresi</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Alım adresini düzenle</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Gönderi adresini düzenle</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book.</source>
        <translation>Girilen "%1" adresi hâlihazırda adres defterinde mevcuttur.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Cüzdan kilidi açılamadı.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Yeni anahtar oluşturulması başarısız oldu.</translation>
    </message>
</context>
<context>
    <name>GUIUtil::HelpMessageBox</name>
    </context>
<context>
    <name>MainOptionsPage</name>
    </context>
<context>
    <name>MintingTableModel</name>
    <message>
        <source>Address</source>
        <translation>Adres</translation>
    </message>
    </context>
<context>
    <name>MintingView</name>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Virgülle ayrılmış değerler dosyası (*.csv)</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adres</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Dışa aktarımda hata oluştu</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>%1 dosyasına yazılamadı.</translation>
    </message>
    </context>
<context>
    <name>MultisigAddressEntry</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Choose address from address book</source>
        <translation>Adres defterinden adres seç</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etiket:</translation>
    </message>
</context>
<context>
    <name>MultisigDialog</name>
    <message>
        <source>Clear all</source>
        <translation>Tümünü temizle</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Panodan adres yapıştır</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    </context>
<context>
    <name>MultisigInputEntry</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
</context>
<context>
    <name>NetworkOptionsPage</name>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Seçenekler</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Bakiye:</translation>
    </message>
    <message>
        <source>Number of transactions:</source>
        <translation>Muamele sayısı:</translation>
    </message>
    <message>
        <source>Unconfirmed:</source>
        <translation>Doğrulanmamış:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;Son muameleler&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Your current balance</source>
        <translation>Güncel bakiyeniz</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the current balance</source>
        <translation>Doğrulanması beklenen ve henüz güncel bakiyeye ilâve edilmemiş muamelelerin toplamı</translation>
    </message>
    <message>
        <source>Total number of transactions in wallet</source>
        <translation>Cüzdandaki muamelelerin toplam sayısı</translation>
    </message>
    </context>
<context>
    <name>QRCodeDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR Kod</translation>
    </message>
    <message>
        <source>Request Payment</source>
        <translation>Ödeme isteği</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Miktar:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etiket:</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Mesaj:</translation>
    </message>
    <message>
        <source>&amp;Save As...</source>
        <translation>&amp;Farklı kaydet...</translation>
    </message>
    <message>
        <source>PNG Images (*.png)</source>
        <translation>PNG resimleri (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Para (coin) yolla</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Miktar:</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Birçok alıcıya aynı anda gönder</translation>
    </message>
    <message>
        <source>Remove all transaction fields</source>
        <translation>Bütün muamele alanlarını kaldır</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Bakiye:</translation>
    </message>
    <message>
        <source>123.456 BTC</source>
        <translation>123.456 BTC</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Yollama etkinliğini teyit ediniz</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Gönder</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Miktarı kopyala</translation>
    </message>
    <message>
        <source>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; şu adrese: %2 (%3)</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Gönderiyi teyit ediniz</translation>
    </message>
    <message>
        <source>Are you sure you want to send %1?</source>
        <translation>%1 tutarını göndermek istediğinizden emin misiniz?</translation>
    </message>
    <message>
        <source> and </source>
        <translation> ve </translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(boş etiket)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>A&amp;mount:</source>
        <translation>M&amp;iktar:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>&amp;Şu kişiye öde:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Adres defterinize eklemek için bu adres için bir etiket giriniz</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Etiket:</translation>
    </message>
    <message>
        <source>Choose address from address book</source>
        <translation>Adres defterinden adres seç</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Panodan adres yapıştır</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this recipient</source>
        <translation>Bu alıcıyı kaldır</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>&amp;Sign Message</source>
        <translation>Mesaj &amp;imzala</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Panodan adres yapıştır</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>%1 değerine dek açık</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/doğrulanmadı</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 doğrulama</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Tarih</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Miktar</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>, henüz başarılı bir şekilde yayınlanmadı</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>bilinmiyor</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>Muamele detayları</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Bu pano muamelenin ayrıntılı açıklamasını gösterir</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Tarih</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tür</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adres</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Miktar</translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>%1 değerine dek açık</translation>
    </message>
    <message>
        <source>Offline (%1 confirmations)</source>
        <translation>Çevrimdışı (%1 doğrulama)</translation>
    </message>
    <message>
        <source>Unconfirmed (%1 of %2 confirmations)</source>
        <translation>Doğrulanmadı (%1 (toplam %2 üzerinden) doğrulama)</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Doğrulandı (%1 doğrulama)</translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Bu blok başka hiçbir düğüm tarafından alınmamıştır ve muhtemelen kabul edilmeyecektir!</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Oluşturuldu ama kabul edilmedi</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Şununla alınan</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Alındığı kişi</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Gönderildiği adres</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Kendinize ödeme</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Madenden çıkarılan</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(mevcut değil)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Muamele durumu. Doğrulama sayısını görüntülemek için imleci bu alanda tutunuz.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Muamelenin alındığı tarih ve zaman.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Muamele türü.</translation>
    </message>
    <message>
        <source>Destination address of transaction.</source>
        <translation>Muamelenin alıcı adresi.</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Bakiyeden alınan ya da bakiyeye eklenen miktar.</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Hepsi</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Bugün</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>Bu hafta</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>Bu ay</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Geçen ay</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>Bu sene</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Aralık...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Şununla alınan</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Gönderildiği adres</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>Kendinize</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Oluşturulan</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Diğer</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Aranacak adres ya da etiket giriniz</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Asgari miktar</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Adresi kopyala</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Etiketi kopyala</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Miktarı kopyala</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Etiketi düzenle</translation>
    </message>
    <message>
        <source>Export Transaction Data</source>
        <translation>Muamele verilerini dışa aktar</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Virgülle ayrılmış değerler dosyası (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Doğrulandı</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Tarih</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tür</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etiket</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adres</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Miktar</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>Kimlik</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Dışa aktarımda hata oluştu</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>%1 dosyasına yazılamadı.</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Aralık:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>ilâ</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Sending...</source>
        <translation>Gönderiliyor...</translation>
    </message>
</context>
<context>
    <name>WindowOptionsPage</name>
    </context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Error: Transaction creation failed  </source>
        <translation>Hata: Muamele oluşturması başarısız oldu  </translation>
    </message>
    <message>
        <source>Sending...</source>
        <translation>Gönderiliyor...</translation>
    </message>
    <message>
        <source>Error: The transaction was rejected.  This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Hata: Muamele reddedildi.  Cüzdanınızdaki madenî paraların bazıları zaten harcanmış olduğunda bu meydana gelebilir. Örneğin wallet.dat dosyasının bir kopyasını kullandıysanız ve kopyada para harcandığında ancak burada harcandığı işaretlenmediğinde.</translation>
    </message>
    </context>
</TS>