<TS language="fi" version="2.0">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>AboutDialog</name>
    </context>
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Address Book</source>
        <translation>Osoitekirja</translation>
    </message>
    <message>
        <source>Double-click to edit address or label</source>
        <translation>Kaksoisnapauta muokataksesi osoitetta tai nimeä</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Luo uusi osoite</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Kopioi valittu osoite leikepöydälle</translation>
    </message>
    <message>
        <source>Show &amp;QR Code</source>
        <translation>Näytä &amp;QR-koodi</translation>
    </message>
    <message>
        <source>Sign a message to prove you own this address</source>
        <translation>Allekirjoita viesti millä todistat omistavasi tämän osoitteen</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;Allekirjoita viesti</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list. Only sending addresses can be deleted.</source>
        <translation>Poista valittuna oleva osoite listasta. Vain lähettämiseen käytettäviä osoitteita voi poistaa.</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Poista</translation>
    </message>
    <message>
        <source>Export Address Book Data</source>
        <translation>Vie osoitekirja</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Comma separated file (*.csv)</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Virhe tietojen viennissä</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>Ei voida kirjoittaa tiedostoon %1.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Osoite</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(ei nimeä)</translation>
    </message>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Enter passphrase</source>
        <translation>Anna tunnuslause</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Uusi tunnuslause</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Toista uusi tunnuslause</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Anna lompakolle uusi tunnuslause.&lt;br/&gt;Käytä tunnuslausetta, jossa on ainakin  &lt;b&gt;10 satunnaista mekkiä&lt;/b&gt; tai &lt;b&gt;kahdeksan sanaa&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Salaa lompakko</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Tätä toimintoa varten sinun täytyy antaa lompakon tunnuslause sen avaamiseksi.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Avaa lompakko</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Tätä toimintoa varten sinun täytyy antaa lompakon tunnuslause salauksen purkuun.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Pura lompakon salaus</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Vaihda tunnuslause</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Hyväksy lompakon salaus</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Lompakko salattu</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on.</source>
        <translation>Varoitus: Caps Lock on päällä.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Lompakon salaus epäonnistui</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Lompakon salaaminen epäonnistui sisäisen virheen vuoksi. Lompakkoa ei salattu.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>Annetut tunnuslauseet eivät täsmää.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Lompakon avaaminen epäonnistui.</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Annettu tunnuslause oli väärä.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Lompakon salauksen purku epäonnistui.</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Lompakon tunnuslause on vaihdettu.</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Yleisnäkymä</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Näyttää kokonaiskatsauksen lompakon tilanteesta</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Rahansiirrot</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Selaa rahansiirtohistoriaa</translation>
    </message>
    <message>
        <source>&amp;Address Book</source>
        <translation>&amp;Osoitekirja</translation>
    </message>
    <message>
        <source>Edit the list of stored addresses and labels</source>
        <translation>Muokkaa tallennettujen nimien ja osoitteiden listaa</translation>
    </message>
    <message>
        <source>&amp;Receive coins</source>
        <translation>&amp;Paycoinien vastaanottaminen</translation>
    </message>
    <message>
        <source>Show the list of addresses for receiving payments</source>
        <translation>Näytä Paycoinien vastaanottamiseen käytetyt osoitteet</translation>
    </message>
    <message>
        <source>&amp;Send coins</source>
        <translation>&amp;Lähetä Paycoineja</translation>
    </message>
    <message>
        <source>Prove you control an address</source>
        <translation>Todista että hallitset osoitetta</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>L&amp;opeta</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Lopeta ohjelma</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Tietoja &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Näytä tietoja QT:ta</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Asetukset...</translation>
    </message>
    <message>
        <source>&amp;Export...</source>
        <translation>&amp;Vie...</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Vie aukiolevan välilehden tiedot tiedostoon</translation>
    </message>
    <message>
        <source>Encrypt or decrypt wallet</source>
        <translation>Kryptaa tai dekryptaa lompakko</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Varmuuskopioi lompakko toiseen sijaintiin</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Vaihda lompakon salaukseen käytettävä tunnuslause</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Tiedosto</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Asetukset</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Apua</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Välilehtipalkki</translation>
    </message>
    <message>
        <source>Actions toolbar</source>
        <translation>Toimintopalkki</translation>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Synkronoidaan verkon kanssa...</translation>
    </message>
    <message>
        <source>Downloaded %1 blocks of transaction history.</source>
        <translation>Ladattu %1 lohkoa rahansiirron historiasta.</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Ohjelmisto on ajan tasalla</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Kurotaan kiinni...</translation>
    </message>
    <message>
        <source>Last received block was generated %1.</source>
        <translation>Viimeisin vastaanotettu lohko tuotettu %1.</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Lähetetyt rahansiirrot</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Saapuva rahansiirto</translation>
    </message>
    <message>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Päivä: %1
Määrä: %2
Tyyppi: %3
Osoite: %4</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Lompakko on &lt;b&gt;salattu&lt;/b&gt; ja tällä hetkellä &lt;b&gt;avoinna&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Lompakko on &lt;b&gt;salattu&lt;/b&gt; ja tällä hetkellä &lt;b&gt;lukittuna&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>Varmuuskopioi lompakko</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>Lompakkodata (*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>Varmuuskopio epäonnistui</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to the new location.</source>
        <translation>Virhe tallennettaessa lompakkodataa uuteen sijaintiin.</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Määrä:</translation>
    </message>
    <message>
        <source>0.00 BTC</source>
        <translation>123,456 BTC {0.00 ?}</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Määrä</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Osoite</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Aika</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Vahvistettu</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopioi osoite</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopioi nimi</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopioi määrä</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(ei nimeä)</translation>
    </message>
    </context>
<context>
    <name>DisplayOptionsPage</name>
    <message>
        <source>&amp;Unit to show amounts in: </source>
        <translation>&amp;Yksikkö, jossa määrät näytetään: </translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface, and when sending coins</source>
        <translation>Valitse oletus lisämääre mikä näkyy käyttöliittymässä ja kun lähetät kolikoita</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Muokkaa osoitetta</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Nimi</translation>
    </message>
    <message>
        <source>The label associated with this address book entry</source>
        <translation>Tähän osoitteeseen liitetty nimi</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Osoite</translation>
    </message>
    <message>
        <source>The address associated with this address book entry. This can only be modified for sending addresses.</source>
        <translation>Osoite, joka liittyy tämän osoitekirjan merkintään. Tätä voidaan muuttaa vain lähtevissä osoitteissa.</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Uusi vastaanottava osoite</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Uusi lähettävä osoite</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Muokkaa vastaanottajan osoitetta</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Muokkaa lähtevää osoitetta</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book.</source>
        <translation>Osoite "%1" on jo osoitekirjassa.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Lompakkoa ei voitu avata.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Uuden avaimen luonti epäonnistui.</translation>
    </message>
</context>
<context>
    <name>GUIUtil::HelpMessageBox</name>
    </context>
<context>
    <name>MainOptionsPage</name>
    </context>
<context>
    <name>MintingTableModel</name>
    <message>
        <source>Address</source>
        <translation>Osoite</translation>
    </message>
    </context>
<context>
    <name>MintingView</name>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Comma separated file (*.csv)</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Osoite</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Virhe tietojen viennissä</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>Ei voida kirjoittaa tiedostoon %1.</translation>
    </message>
    </context>
<context>
    <name>MultisigAddressEntry</name>
    <message>
        <source>Form</source>
        <translation>Lomake</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Choose address from address book</source>
        <translation>Valitse osoite osoitekirjasta</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Tunniste:</translation>
    </message>
</context>
<context>
    <name>MultisigDialog</name>
    <message>
        <source>Clear all</source>
        <translation>Tyhjennä lista</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Liitä osoite leikepöydältä</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    </context>
<context>
    <name>MultisigInputEntry</name>
    <message>
        <source>Form</source>
        <translation>Lomake</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
</context>
<context>
    <name>NetworkOptionsPage</name>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Asetukset</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Lomake</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Saldo:</translation>
    </message>
    <message>
        <source>Number of transactions:</source>
        <translation>Rahansiirtojen lukumäärä:</translation>
    </message>
    <message>
        <source>Unconfirmed:</source>
        <translation>Vahvistamatta:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;Viimeisimmät rahansiirrot&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Your current balance</source>
        <translation>Tililläsi tällä hetkellä olevien Paycoinien määrä</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the current balance</source>
        <translation>Niiden saapuvien rahansiirtojen määrä, joita Paycoin-verkko ei vielä ole ehtinyt vahvistaa ja siten eivät vielä näy saldossa.</translation>
    </message>
    <message>
        <source>Total number of transactions in wallet</source>
        <translation>Lompakolla tehtyjen rahansiirtojen yhteismäärä</translation>
    </message>
    </context>
<context>
    <name>QRCodeDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR-koodi</translation>
    </message>
    <message>
        <source>Request Payment</source>
        <translation>Vastaanota maksu</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Määrä:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Tunniste:</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Viesti:</translation>
    </message>
    <message>
        <source>&amp;Save As...</source>
        <translation>&amp;Tallenna nimellä...</translation>
    </message>
    <message>
        <source>PNG Images (*.png)</source>
        <translation>PNG kuvat (*png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Lähetä Paycoineja</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Määrä:</translation>
    </message>
    <message>
        <source>0.00 BTC</source>
        <translation>123,456 BTC {0.00 ?}</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Lähetä monelle vastaanottajalle</translation>
    </message>
    <message>
        <source>Remove all transaction fields</source>
        <translation>Poista kaikki rahansiiron kentät</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Saldo:</translation>
    </message>
    <message>
        <source>123.456 BTC</source>
        <translation>123,456 BTC</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Vahvista lähetys</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Lähetä</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopioi määrä</translation>
    </message>
    <message>
        <source>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Hyväksy Paycoinien lähettäminen</translation>
    </message>
    <message>
        <source>Are you sure you want to send %1?</source>
        <translation>Haluatko varmasti lähettää %1?</translation>
    </message>
    <message>
        <source> and </source>
        <translation> ja </translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(ei nimeä)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>Form</source>
        <translation>Lomake</translation>
    </message>
    <message>
        <source>A&amp;mount:</source>
        <translation>M&amp;äärä:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>Maksun saaja:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Anna nimi tälle osoitteelle, jos haluat lisätä sen osoitekirjaan</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Nimi:</translation>
    </message>
    <message>
        <source>Choose address from address book</source>
        <translation>Valitse osoite osoitekirjasta</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Liitä osoite leikepöydältä</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this recipient</source>
        <translation>Poista </translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;Allekirjoita viesti</translation>
    </message>
    <message>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Voit allekirjoittaa viestit omalla osoitteellasi todistaaksesi että omistat ne. Ole huolellinen, että et allekirjoita mitään epämääräistä, phishing-hyökkääjät voivat huijata sinua allekirjoittamaan luovuttamalla henkilöllisyytesi. Allekirjoita selvitys täysin yksityiskohtaisesti mihin olet sitoutunut.</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Liitä osoite leikepöydältä</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Kirjoita tähän viesti minkä haluat allekirjoittaa</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>Avoinna %1 asti</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/vahvistamaton</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 vahvistusta</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Aika</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Määrä</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>, ei ole vielä onnistuneesti lähetetty</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>tuntematon</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>Rahansiirron yksityiskohdat</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Tämä ruutu näyttää yksityiskohtaisen tiedon rahansiirrosta</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Aika</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Laatu</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Osoite</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Määrä</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n block(s)</source>
        <translation><numerusform>Auki %n lohkolle</numerusform><numerusform>Auki %n lohkoille</numerusform></translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Avoinna %1 asti</translation>
    </message>
    <message>
        <source>Offline (%1 confirmations)</source>
        <translation>Ei yhteyttä verkkoon (%1 vahvistusta)</translation>
    </message>
    <message>
        <source>Unconfirmed (%1 of %2 confirmations)</source>
        <translation>Vahvistamatta (%1/%2 vahvistusta)</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Vahvistettu (%1 vahvistusta)</translation>
    </message>
    <message numerus="yes">
        <source>Mined balance will be available in %n more blocks</source>
        <translation><numerusform>Louhittu saldo tulee saataville %n lohkossa</numerusform><numerusform>Louhittu saldo tulee saataville %n lohkossa</numerusform></translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Tätä lohkoa ei vastaanotettu mistään muusta solmusta ja sitä ei mahdollisesti hyväksytty!</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Generoitu mutta ei hyväksytty</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Vastaanotettu osoitteella</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Vastaanotettu</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Saaja</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Maksu itsellesi</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Louhittu</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(ei saatavilla)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Rahansiirron tila. Siirrä osoitin kentän päälle nähdäksesi vahvistusten lukumäärä.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Rahansiirron vastaanottamisen päivämäärä ja aika.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Rahansiirron laatu.</translation>
    </message>
    <message>
        <source>Destination address of transaction.</source>
        <translation>Rahansiirron kohteen Paycoin-osoite</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Saldoon lisätty tai siitä vähennetty määrä.</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Kaikki</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Tänään</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>Tällä viikolla</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>Tässä kuussa</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Viime kuussa</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>Tänä vuonna</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Alue...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Vastaanotettu osoitteella</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Saaja</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>Itsellesi</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Louhittu</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Muu</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Anna etsittävä osoite tai tunniste</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Minimimäärä</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopioi osoite</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopioi nimi</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopioi määrä</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Muokkaa nimeä</translation>
    </message>
    <message>
        <source>Export Transaction Data</source>
        <translation>Vie transaktion tiedot</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Comma separated file (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Vahvistettu</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Aika</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Laatu</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Osoite</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Määrä</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Virhe tietojen viennissä</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>Ei voida kirjoittaa tiedostoon %1.</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Alue:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>kenelle</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Sending...</source>
        <translation>Lähetetään...</translation>
    </message>
</context>
<context>
    <name>WindowOptionsPage</name>
    </context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Usage:</source>
        <translation>Käyttö:</translation>
    </message>
    <message>
        <source>List commands</source>
        <translation>Lista komennoista</translation>
    </message>
    <message>
        <source>Get help for a command</source>
        <translation>Hanki apua käskyyn</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Asetukset:</translation>
    </message>
    <message>
        <source>Specify pid file (default: paycoind.pid)</source>
        <translation>Määritä pid-tiedosto (oletus: Paycoin.pid)</translation>
    </message>
    <message>
        <source>Generate coins</source>
        <translation>Generoi kolikoita</translation>
    </message>
    <message>
        <source>Don't generate coins</source>
        <translation>Älä generoi kolikoita</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Määritä data-hakemisto</translation>
    </message>
    <message>
        <source>Specify connection timeout (in milliseconds)</source>
        <translation>Määritä yhteyden aikakatkaisu (millisekunneissa)</translation>
    </message>
    <message>
        <source>Maintain at most &lt;n&gt; connections to peers (default: 125)</source>
        <translation>Pidä enintään &lt;n&gt; yhteyttä verkkoihin (oletus: 125)</translation>
    </message>
    <message>
        <source>Connect only to the specified node</source>
        <translation>Ota yhteys vain tiettyyn solmuun</translation>
    </message>
    <message>
        <source>Threshold for disconnecting misbehaving peers (default: 100)</source>
        <translation>Kynnysarvo aikakatkaisulle heikosti toimiville verkoille (oletus: 100)</translation>
    </message>
    <message>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: 86400)</source>
        <translation>Sekuntien määrä, kuinka kauan uudelleenkytkeydytään verkkoihin (oletus: 86400)</translation>
    </message>
    <message>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: 10000)</source>
        <translation>Maksimi verkkoyhteyden vastaanottopuskuri, &lt;n&gt;*1000 tavua (oletus: 10000)</translation>
    </message>
    <message>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: 10000)</source>
        <translation>Maksimi verkkoyhteyden lähetyspuskuri, &lt;n&gt;*1000 tavua (oletus: 10000)</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Aja taustalla daemonina ja hyväksy komennot</translation>
    </message>
    <message>
        <source>Use the test network</source>
        <translation>Käytä test -verkkoa</translation>
    </message>
    <message>
        <source>Prepend debug output with timestamp</source>
        <translation>Lisää debuggaustiedon tulostukseen aikaleima</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Lähetä jäljitys/debug-tieto konsoliin, debug.log-tiedoston sijaan</translation>
    </message>
    <message>
        <source>Send trace/debug info to debugger</source>
        <translation>Lähetä jäljitys/debug-tieto debuggeriin</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Käyttäjätunnus JSON-RPC-yhteyksille</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Salasana JSON-RPC-yhteyksille</translation>
    </message>
    <message>
        <source>Allow JSON-RPC connections from specified IP address</source>
        <translation>Salli JSON-RPC yhteydet tietystä ip-osoitteesta</translation>
    </message>
    <message>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</source>
        <translation>Lähetä käskyjä solmuun osoitteessa &lt;ip&gt; (oletus: 127.0.0.1)</translation>
    </message>
    <message>
        <source>Set key pool size to &lt;n&gt; (default: 100)</source>
        <translation>Aseta avainpoolin koko arvoon &lt;n&gt; (oletus: 100)</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Skannaa uudelleen lohkoketju lompakon puuttuvien rahasiirtojen vuoksi</translation>
    </message>
    <message>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>Käytä OpenSSL:ää (https) JSON-RPC-yhteyksille</translation>
    </message>
    <message>
        <source>Server certificate file (default: server.cert)</source>
        <translation>Palvelimen sertifikaatti-tiedosto (oletus: server.cert)</translation>
    </message>
    <message>
        <source>Server private key (default: server.pem)</source>
        <translation>Palvelimen yksityisavain (oletus: server.pem)</translation>
    </message>
    <message>
        <source>Acceptable ciphers (default: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</source>
        <translation>Hyväksyttävä salaus (oletus:
TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Ladataan osoitteita...</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Ladataan lohkoindeksiä...</translation>
    </message>
    <message>
        <source>Error loading blkindex.dat</source>
        <translation>Virhe ladattaessa blkindex.dat-tiedostoa</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Ladataan lompakkoa...</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Virhe ladattaessa wallet.dat-tiedostoa: Lompakko vioittunut</translation>
    </message>
    <message>
        <source>Error loading wallet.dat</source>
        <translation>Virhe ladattaessa wallet.dat-tiedostoa</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Skannataan uudelleen...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Lataus on valmis</translation>
    </message>
    <message>
        <source>Warning: -paytxfee is set very high.  This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Varoitus:-paytxfee on erittäin korkea. Tämä on palkkio siirrosta minkä suoritat rahansiirrosta.</translation>
    </message>
    <message>
        <source>Error: Transaction creation failed  </source>
        <translation>Virhe: Rahansiirron luonti epäonnistui</translation>
    </message>
    <message>
        <source>Sending...</source>
        <translation>Lähetetään...</translation>
    </message>
    <message>
        <source>Error: The transaction was rejected.  This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Virhe: Rahansiirto hylättiin.  Tämä voi tapahtua jos jotkin Paycoineistasi on jo käytetty, esimerkiksi jos olet käyttänyt kopiota wallet.dat-lompakkotiedostosta ja Paycoinit on merkitty käytetyksi vain kopiossa.</translation>
    </message>
    </context>
</TS>