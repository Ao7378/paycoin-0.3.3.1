<TS language="cs_CZ" version="2.0">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>AboutDialog</name>
    </context>
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Address Book</source>
        <translation>Adresář</translation>
    </message>
    <message>
        <source>Double-click to edit address or label</source>
        <translation>Dvojklikem myši začneš upravovat označení adresy</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Vytvoř novou adresu</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Zkopíruj aktuálně vybranou adresu do systémové schránky</translation>
    </message>
    <message>
        <source>Show &amp;QR Code</source>
        <translation>Zobraz &amp;QR kód</translation>
    </message>
    <message>
        <source>Sign a message to prove you own this address</source>
        <translation>Podepiš zprávu, čímž prokážeš, že jsi vlastníkem této adresy</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>Po&amp;depiš zprávu</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list. Only sending addresses can be deleted.</source>
        <translation>Smaž aktuálně vybranou adresu ze seznamu. Smazány mohou být pouze adresy příjemců.</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>S&amp;maž</translation>
    </message>
    <message>
        <source>Export Address Book Data</source>
        <translation>Exportuj data adresáře</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>CSV formát (*.csv)</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Chyba při exportu</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>Nemohu zapisovat do souboru %1.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Označení</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(bez označení)</translation>
    </message>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Enter passphrase</source>
        <translation>Zadej platné heslo</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Zadej nové heslo</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Totéž heslo ještě jednou</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Zadej nové heslo k peněžence.&lt;br/&gt;Použij &lt;b&gt;alespoň 10 náhodných znaků&lt;/b&gt; nebo &lt;b&gt;alespoň osm slov&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Zašifruj peněženku</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>K provedení této operace musíš zadat heslo k peněžence, aby se mohla odemknout.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Odemkni peněženku</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>K provedení této operace musíš zadat heslo k peněžence, aby se mohla dešifrovat.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Dešifruj peněženku</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Změň heslo</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Potvrď zašifrování peněženky</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Peněženka je zašifrována</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on.</source>
        <translation>Upozornění: Caps Lock je zapnutý.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Zašifrování peněženky selhalo</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Zašifrování peněženky selhalo kvůli vnitřní chybě. Tvá peněženka tedy nebyla zašifrována.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>Zadaná hesla nejsou shodná.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Odemčení peněženky selhalo</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Nezadal jsi správné heslo pro dešifrování peněženky.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Dešifrování peněženky selhalo</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Heslo k peněžence bylo v pořádku změněno.</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Přehled</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Zobraz celkový přehled peněženky</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transakce</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Procházet historii transakcí</translation>
    </message>
    <message>
        <source>&amp;Address Book</source>
        <translation>&amp;Adresář</translation>
    </message>
    <message>
        <source>Edit the list of stored addresses and labels</source>
        <translation>Uprav seznam uložených adres a jejich označení</translation>
    </message>
    <message>
        <source>&amp;Receive coins</source>
        <translation>Pří&amp;jem mincí</translation>
    </message>
    <message>
        <source>Show the list of addresses for receiving payments</source>
        <translation>Zobraz seznam adres pro příjem plateb</translation>
    </message>
    <message>
        <source>&amp;Send coins</source>
        <translation>P&amp;oslání mincí</translation>
    </message>
    <message>
        <source>Prove you control an address</source>
        <translation>Prokaž vlastnictví adresy</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Konec</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Ukončit aplikaci</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>O &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Zobraz informace o Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Možnosti...</translation>
    </message>
    <message>
        <source>&amp;Export...</source>
        <translation>&amp;Export...</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Exportovat data z tohoto panelu do souboru</translation>
    </message>
    <message>
        <source>Encrypt or decrypt wallet</source>
        <translation>Zašifruj nebo dešifruj peněženku</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Zazálohuj peněženku na jiné místo</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Změň heslo k šifrování peněženky</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Soubor</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Nastavení</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>Ná&amp;pověda</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Panel s listy</translation>
    </message>
    <message>
        <source>Actions toolbar</source>
        <translation>Panel akcí</translation>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Synchronizuji se sítí...</translation>
    </message>
    <message>
        <source>Downloaded %1 blocks of transaction history.</source>
        <translation>Staženo %1 bloků transakční historie.</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>aktuální</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Stahuji...</translation>
    </message>
    <message>
        <source>Last received block was generated %1.</source>
        <translation>Poslední stažený blok byl vygenerován %1.</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Odeslané transakce</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Příchozí transakce</translation>
    </message>
    <message>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Datum: %1
Částka: %2
Typ: %3
Adresa: %4
</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Peněženka je &lt;b&gt;zašifrovaná&lt;/b&gt; a momentálně &lt;b&gt;odemčená&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Peněženka je &lt;b&gt;zašifrovaná&lt;/b&gt; a momentálně &lt;b&gt;zamčená&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>Záloha peněženky</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>Data peněženky (*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>Zálohování selhalo</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to the new location.</source>
        <translation>Při ukládání peněženky na nové místo se přihodila nějaká chyba.</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Částka:</translation>
    </message>
    <message>
        <source>0.00 BTC</source>
        <translation>123.456 BTC {0.00 ?}</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Částka</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Potvrzeno</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopíruj adresu</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopíruj její označení</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopíruj částku</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(bez označení)</translation>
    </message>
    </context>
<context>
    <name>DisplayOptionsPage</name>
    <message>
        <source>&amp;Unit to show amounts in: </source>
        <translation>&amp;Jednotka pro částky: </translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface, and when sending coins</source>
        <translation>Zvol výchozí podjednotku, která se bude zobrazovat v programu a při posílání mincí</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Uprav adresu</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Označení</translation>
    </message>
    <message>
        <source>The label associated with this address book entry</source>
        <translation>Označení spojené s tímto záznamem v adresáři</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Adresa</translation>
    </message>
    <message>
        <source>The address associated with this address book entry. This can only be modified for sending addresses.</source>
        <translation>Adresa spojená s tímto záznamem v adresáři. Lze upravovat jen pro odesílací adresy.</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Nová přijímací adresa</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Nová odesílací adresa</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Uprav přijímací adresu</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Uprav odesílací adresu</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book.</source>
        <translation>Zadaná adresa "%1" už v adresáři je.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Nemohu odemknout peněženku.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Nepodařilo se mi vygenerovat nový klíč.</translation>
    </message>
</context>
<context>
    <name>GUIUtil::HelpMessageBox</name>
    </context>
<context>
    <name>MainOptionsPage</name>
    </context>
<context>
    <name>MintingTableModel</name>
    <message>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    </context>
<context>
    <name>MintingView</name>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>CSV formát (*.csv)</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Chyba při exportu</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>Nemohu zapisovat do souboru %1.</translation>
    </message>
    </context>
<context>
    <name>MultisigAddressEntry</name>
    <message>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Choose address from address book</source>
        <translation>Vyber adresu z adresáře</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Označení:</translation>
    </message>
</context>
<context>
    <name>MultisigDialog</name>
    <message>
        <source>Clear all</source>
        <translation>Všechno smaž</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Vlož adresu ze schránky</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    </context>
<context>
    <name>MultisigInputEntry</name>
    <message>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
</context>
<context>
    <name>NetworkOptionsPage</name>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Možnosti</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Stav účtu:</translation>
    </message>
    <message>
        <source>Number of transactions:</source>
        <translation>Počet transakcí:</translation>
    </message>
    <message>
        <source>Unconfirmed:</source>
        <translation>Nepotvrzeno:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;Poslední transakce&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Your current balance</source>
        <translation>Aktuální stav tvého účtu</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the current balance</source>
        <translation>Celkem z transakcí, které ještě nejsou potvrzené a které se ještě nezapočítávají do celkového stavu účtu</translation>
    </message>
    <message>
        <source>Total number of transactions in wallet</source>
        <translation>Celkový počet transakcí v peněžence</translation>
    </message>
    </context>
<context>
    <name>QRCodeDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR kód</translation>
    </message>
    <message>
        <source>Request Payment</source>
        <translation>Požadovat platbu</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Částka:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Označení:</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Zpráva:</translation>
    </message>
    <message>
        <source>&amp;Save As...</source>
        <translation>&amp;Ulož jako...</translation>
    </message>
    <message>
        <source>PNG Images (*.png)</source>
        <translation>PNG obrázky (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Pošli mince</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Částka:</translation>
    </message>
    <message>
        <source>0.00 BTC</source>
        <translation>123.456 BTC {0.00 ?}</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Pošli více příjemcům naráz</translation>
    </message>
    <message>
        <source>Remove all transaction fields</source>
        <translation>Smaž všechny transakční formuláře</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Stav účtu:</translation>
    </message>
    <message>
        <source>123.456 BTC</source>
        <translation>123.456 BTC</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Potvrď odeslání</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Pošli</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopíruj částku</translation>
    </message>
    <message>
        <source>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; pro %2 (%3)</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Potvrď odeslání mincí</translation>
    </message>
    <message>
        <source>Are you sure you want to send %1?</source>
        <translation>Jsi si jistý, že chceš poslat %1?</translation>
    </message>
    <message>
        <source> and </source>
        <translation> a </translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(bez označení)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>Form</source>
        <translation>Formulář</translation>
    </message>
    <message>
        <source>A&amp;mount:</source>
        <translation>Čá&amp;stka:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>&amp;Komu:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Zadej označení této adresy; obojí se ti pak uloží do adresáře</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Označení:</translation>
    </message>
    <message>
        <source>Choose address from address book</source>
        <translation>Vyber adresu z adresáře</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Vlož adresu ze schránky</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this recipient</source>
        <translation>Smaž tohoto příjemce</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>&amp;Sign Message</source>
        <translation>Po&amp;depiš zprávu</translation>
    </message>
    <message>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Podepsáním zprávy svými adresami můžeš prokázat, že je skutečně vlastníš. Buď opatrný a nepodepisuj nic vágního; například při phishingových útocích můžeš být lákán, abys něco takového podepsal. Podepisuj pouze zcela úplná a detailní prohlášení, se kterými souhlasíš.</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Vlož adresu ze schránky</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Sem vepiš zprávu, kterou chceš podepsat</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>Otřevřeno dokud %1</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/nepotvrzeno</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 potvrzení</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Částka</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>, ještě nebylo rozesláno</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>neznámo</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>Detaily transakce</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Toto okno zobrazuje detailní popis transakce</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Částka</translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Otřevřeno dokud %1</translation>
    </message>
    <message>
        <source>Offline (%1 confirmations)</source>
        <translation>Offline (%1 potvrzení)</translation>
    </message>
    <message>
        <source>Unconfirmed (%1 of %2 confirmations)</source>
        <translation>Nepotvrzeno (%1 z %2 potvrzení)</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Potvrzeno (%1 potvrzení)</translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Tento blok nedostal žádný jiný uzel a pravděpodobně nebude akceptován!</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Vygenerováno, ale neakceptováno</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Přijato do</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Přijato od</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Posláno na</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Platba sama sobě</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Vytěženo</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(n/a)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Stav transakce. Najetím myši na toto políčko si zobrazíš počet potvrzení.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Datum a čas přijetí transakce.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Druh transakce.</translation>
    </message>
    <message>
        <source>Destination address of transaction.</source>
        <translation>Cílová adresa transakce.</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Částka odečtená z nebo přičtená k účtu.</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Vše</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Dnes</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>Tento týden</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>Tento měsíc</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Minulý měsíc</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>Letos</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Rozsah...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Přijato do</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Posláno na</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>Sám sobě</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Vytěženo</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Ostatní</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Zadej adresu nebo označení pro její vyhledání</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Minimální částka</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopíruj adresu</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopíruj její označení</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopíruj částku</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Uprav označení</translation>
    </message>
    <message>
        <source>Export Transaction Data</source>
        <translation>Exportuj transakční data</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>CSV formát (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Potvrzeno</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Označení</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Částka</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Chyba při exportu</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>Nemohu zapisovat do souboru %1.</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Rozsah:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>až</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Sending...</source>
        <translation>Posílám...</translation>
    </message>
</context>
<context>
    <name>WindowOptionsPage</name>
    </context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Usage:</source>
        <translation>Užití:</translation>
    </message>
    <message>
        <source>List commands</source>
        <translation>Výpis příkazů</translation>
    </message>
    <message>
        <source>Get help for a command</source>
        <translation>Získat nápovědu pro příkaz</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Možnosti:</translation>
    </message>
    <message>
        <source>Specify pid file (default: paycoind.pid)</source>
        <translation>PID soubor (výchozí: paycoind.pid)</translation>
    </message>
    <message>
        <source>Generate coins</source>
        <translation>Generovat mince</translation>
    </message>
    <message>
        <source>Don't generate coins</source>
        <translation>Negenerovat mince</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Adresář pro data</translation>
    </message>
    <message>
        <source>Specify connection timeout (in milliseconds)</source>
        <translation>Zadej časový limit spojení (v milisekundách)</translation>
    </message>
    <message>
        <source>Maintain at most &lt;n&gt; connections to peers (default: 125)</source>
        <translation>Povol nejvýše &lt;n&gt; připojení k uzlům (výchozí: 125)</translation>
    </message>
    <message>
        <source>Connect only to the specified node</source>
        <translation>Připojovat se pouze k udanému uzlu</translation>
    </message>
    <message>
        <source>Threshold for disconnecting misbehaving peers (default: 100)</source>
        <translation>Práh pro odpojování nesprávně se chovajících uzlů (výchozí: 100)</translation>
    </message>
    <message>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: 86400)</source>
        <translation>Doba ve vteřinách, po kterou se nebudou moci nesprávně se chovající uzly znovu připojit (výchozí: 86400)</translation>
    </message>
    <message>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: 10000)</source>
        <translation>Maximální velikost přijímacího bufferu pro každé spojení, &lt;n&gt;*1000 bytů (výchozí: 10000)</translation>
    </message>
    <message>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: 10000)</source>
        <translation>Maximální velikost odesílacího bufferu pro každé spojení, &lt;n&gt;*1000 bytů (výchozí: 10000)</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Běžet na pozadí jako démon a akceptovat příkazy</translation>
    </message>
    <message>
        <source>Use the test network</source>
        <translation>Použít testovací síť (testnet)</translation>
    </message>
    <message>
        <source>Prepend debug output with timestamp</source>
        <translation>Připojit před ladící výstup časové razítko</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Posílat stopovací/ladící informace do konzole místo do souboru debug.log</translation>
    </message>
    <message>
        <source>Send trace/debug info to debugger</source>
        <translation>Posílat stopovací/ladící informace do debuggeru</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Uživatelské jméno pro JSON-RPC spojení</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Heslo pro JSON-RPC spojení</translation>
    </message>
    <message>
        <source>Allow JSON-RPC connections from specified IP address</source>
        <translation>Povolit JSON-RPC spojení ze specifikované IP adresy</translation>
    </message>
    <message>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</source>
        <translation>Posílat příkazy uzlu běžícím na &lt;ip&gt; (výchozí: 127.0.0.1)</translation>
    </message>
    <message>
        <source>Set key pool size to &lt;n&gt; (default: 100)</source>
        <translation>Nastavit zásobník klíčů na velikost &lt;n&gt; (výchozí: 100)</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Přeskenovat řetězec bloků na chybějící transakce tvé pěněženky</translation>
    </message>
    <message>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>Použít OpenSSL (https) pro JSON-RPC spojení</translation>
    </message>
    <message>
        <source>Server certificate file (default: server.cert)</source>
        <translation>Soubor se serverovým certifikátem (výchozí: server.cert)</translation>
    </message>
    <message>
        <source>Server private key (default: server.pem)</source>
        <translation>Soubor se serverovým soukromým klíčem (výchozí: server.pem)</translation>
    </message>
    <message>
        <source>Acceptable ciphers (default: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</source>
        <translation>Akceptovatelné šifry (výchozí: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Načítám adresy...</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Načítám index bloků...</translation>
    </message>
    <message>
        <source>Error loading blkindex.dat</source>
        <translation>Chyba při načítání blkindex.dat</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Načítám peněženku...</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Chyba při načítání wallet.dat: peněženka je poškozená</translation>
    </message>
    <message>
        <source>Error loading wallet.dat</source>
        <translation>Chyba při načítání wallet.dat</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Přeskenovávám...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Načítání dokončeno</translation>
    </message>
    <message>
        <source>Warning: -paytxfee is set very high.  This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Upozornění: -paytxfee je nastaveno velmi vysoko.  Toto je transakční poplatek, který zaplatíš za každou poslanou transakci.</translation>
    </message>
    <message>
        <source>Error: Transaction creation failed  </source>
        <translation>Chyba: Vytvoření transakce selhalo  </translation>
    </message>
    <message>
        <source>Sending...</source>
        <translation>Posílám...</translation>
    </message>
    <message>
        <source>Error: The transaction was rejected.  This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Chyba Transakce byla odmítnuta.  Tohle může nastat, pokud nějaké mince z tvé peněženky už jednou byly utraceny, například pokud používáš kopii souboru wallet.dat a mince byly utraceny v druhé kopii, ale nebyly označeny jako utracené v této.</translation>
    </message>
    </context>
</TS>