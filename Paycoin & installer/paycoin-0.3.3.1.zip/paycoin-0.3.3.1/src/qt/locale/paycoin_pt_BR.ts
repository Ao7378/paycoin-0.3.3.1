<TS language="pt_BR" version="2.0">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>AboutDialog</name>
    </context>
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Address Book</source>
        <translation>Catálogo de endereços</translation>
    </message>
    <message>
        <source>Double-click to edit address or label</source>
        <translation>Clique duas vezes para editar o endereço ou o etiqueta</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Criar um novo endereço</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copie o endereço selecionado para a área de transferência do sistema</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list. Only sending addresses can be deleted.</source>
        <translation>Excluir o endereço selecionado da lista. Apenas endereços de envio podem ser excluídos.</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;amp; Excluir</translation>
    </message>
    <message>
        <source>Export Address Book Data</source>
        <translation>Exportação de dados do Catálogo de Endereços</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Arquivo separado por vírgulas (*. csv)</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Erro ao exportar</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>Could not write to file %1.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Rótulo</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Endereço</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(Sem rótulo)</translation>
    </message>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Enter passphrase</source>
        <translation>Digite a frase de segurança</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Nova frase de segurança</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Repita a nova frase de segurança</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Digite a nova frase de seguraça da sua carteira. &lt;br/&gt; Por favor, use uma frase de &lt;b&gt;10 ou mais caracteres aleatórios,&lt;/b&gt; ou &lt;b&gt;oito ou mais palavras.&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Criptografar carteira</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Esta operação precisa de sua frase de segurança para desbloquear a carteira.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Desbloquear carteira</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Esta operação precisa de sua frase de segurança para descriptografar a carteira.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Descriptografar carteira</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Alterar frase de segurança</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Confirmar criptografia da carteira</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Carteira criptografada</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>A criptografia da carteira falhou</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>A criptografia da carteira falhou devido a um erro interno. Sua carteira não estava criptografada.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>A frase de segurança fornecida não confere.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>A abertura da carteira falhou</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>A frase de segurança digitada para a descriptografia da carteira estava incorreta.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>A descriptografia da carteira falhou</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>A frase de segurança da carteira foi alterada com êxito.</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Visão geral</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Mostrar visão geral da carteira</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transações</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Navegar pelo histórico de transações</translation>
    </message>
    <message>
        <source>&amp;Address Book</source>
        <translation>&amp;Catálogo de endereços</translation>
    </message>
    <message>
        <source>Edit the list of stored addresses and labels</source>
        <translation>Editar a lista de endereços e rótulos</translation>
    </message>
    <message>
        <source>&amp;Receive coins</source>
        <translation>&amp;Receber moedas</translation>
    </message>
    <message>
        <source>Show the list of addresses for receiving payments</source>
        <translation>Mostrar a lista de endereços para receber pagamentos</translation>
    </message>
    <message>
        <source>&amp;Send coins</source>
        <translation>&amp;Enviar moedas</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>E&amp;xit</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Sair da aplicação</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Opções...</translation>
    </message>
    <message>
        <source>&amp;Export...</source>
        <translation>&amp;Exportar...</translation>
    </message>
    <message>
        <source>Encrypt or decrypt wallet</source>
        <translation>Criptografar ou decriptogravar carteira</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Mudar a frase de segurança utilizada na criptografia da carteira</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;amp; Arquivo</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>E configurações</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;amp; Ajuda</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Barra de ferramentas</translation>
    </message>
    <message>
        <source>Actions toolbar</source>
        <translation>Barra de ações</translation>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Sincronizando com a rede...</translation>
    </message>
    <message>
        <source>Downloaded %1 blocks of transaction history.</source>
        <translation>Carregados %1 blocos do histórico de transações.</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Atualizado</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Recuperando o atraso ...</translation>
    </message>
    <message>
        <source>Last received block was generated %1.</source>
        <translation>Last received block was generated %1.</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Sent transaction</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Incoming transaction</translation>
    </message>
    <message>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Data: %1
Quantidade: %2
Tipo: %3
Endereço: %4</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>0.00 BTC</source>
        <translation>123.456 BTC {0.00 ?}</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Amount</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Address</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Confirmed</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Copy address</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Copy label</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(Sem rótulo)</translation>
    </message>
    </context>
<context>
    <name>DisplayOptionsPage</name>
    <message>
        <source>&amp;Unit to show amounts in: </source>
        <translation>&amp;Unit to show amounts in: </translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface, and when sending coins</source>
        <translation>Choose the default subdivision unit to show in the interface, and when sending coins</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Edit Address</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Label</translation>
    </message>
    <message>
        <source>The label associated with this address book entry</source>
        <translation>The label associated with this address book entry</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Address</translation>
    </message>
    <message>
        <source>The address associated with this address book entry. This can only be modified for sending addresses.</source>
        <translation>The address associated with this address book entry. This can only be modified for sending addresses.</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>New receiving address</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>New sending address</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Edit receiving address</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Edit sending address</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book.</source>
        <translation>The entered address "%1" is already in the address book.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Could not unlock wallet.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>New key generation failed.</translation>
    </message>
</context>
<context>
    <name>GUIUtil::HelpMessageBox</name>
    </context>
<context>
    <name>MainOptionsPage</name>
    </context>
<context>
    <name>MintingTableModel</name>
    <message>
        <source>Address</source>
        <translation>Address</translation>
    </message>
    </context>
<context>
    <name>MintingView</name>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Comma separated file (*.csv)</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Address</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Error exporting</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>Could not write to file %1.</translation>
    </message>
    </context>
<context>
    <name>MultisigAddressEntry</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Choose address from address book</source>
        <translation>Choose address from address book</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    </context>
<context>
    <name>MultisigDialog</name>
    <message>
        <source>Clear all</source>
        <translation>Clear all</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Paste address from clipboard</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    </context>
<context>
    <name>MultisigInputEntry</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
</context>
<context>
    <name>NetworkOptionsPage</name>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Options</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Balance:</translation>
    </message>
    <message>
        <source>Number of transactions:</source>
        <translation>Number of transactions:</translation>
    </message>
    <message>
        <source>Unconfirmed:</source>
        <translation>Unconfirmed:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;Recent transactions&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Your current balance</source>
        <translation>Your current balance</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the current balance</source>
        <translation>Total of transactions that have yet to be confirmed, and do not yet count toward the current balance</translation>
    </message>
    <message>
        <source>Total number of transactions in wallet</source>
        <translation>Total number of transactions in wallet</translation>
    </message>
    </context>
<context>
    <name>QRCodeDialog</name>
    <message>
        <source>Message:</source>
        <translation>Message:</translation>
    </message>
    </context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Send Coins</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>0.00 BTC</source>
        <translation>123.456 BTC {0.00 ?}</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Send to multiple recipients at once</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Balance:</translation>
    </message>
    <message>
        <source>123.456 BTC</source>
        <translation>123.456 BTC</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Confirm the send action</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Send</translation>
    </message>
    <message>
        <source>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Confirm send coins</translation>
    </message>
    <message>
        <source>Are you sure you want to send %1?</source>
        <translation>Are you sure you want to send %1?</translation>
    </message>
    <message>
        <source> and </source>
        <translation> and </translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(Sem rótulo)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>A&amp;mount:</source>
        <translation>A&amp;mount:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>Pay &amp;To:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Enter a label for this address to add it to your address book</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Label:</translation>
    </message>
    <message>
        <source>Choose address from address book</source>
        <translation>Choose address from address book</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Paste address from clipboard</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this recipient</source>
        <translation>Remove this recipient</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Paste address from clipboard</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>Open until %1</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/unconfirmed</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 confirmations</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Amount</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>, has not been successfully broadcast yet</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>unknown</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>Transaction details</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>This pane shows a detailed description of the transaction</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Address</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Amount</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n block(s)</source>
        <translation><numerusform>Open for %n block</numerusform><numerusform>Open for %n blocks</numerusform></translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Open until %1</translation>
    </message>
    <message>
        <source>Offline (%1 confirmations)</source>
        <translation>Offline (%1 confirmations)</translation>
    </message>
    <message>
        <source>Unconfirmed (%1 of %2 confirmations)</source>
        <translation>Unconfirmed (%1 of %2 confirmations)</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Confirmed (%1 confirmations)</translation>
    </message>
    <message numerus="yes">
        <source>Mined balance will be available in %n more blocks</source>
        <translation><numerusform>Mined balance will be available in %n more block</numerusform><numerusform>Mined balance will be available in %n more blocks</numerusform></translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>This block was not received by any other nodes and will probably not be accepted!</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Generated but not accepted</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Received with</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Sent to</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Payment to yourself</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Mined</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(n/a)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Transaction status. Hover over this field to show number of confirmations.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Date and time that the transaction was received.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Type of transaction.</translation>
    </message>
    <message>
        <source>Destination address of transaction.</source>
        <translation>Destination address of transaction.</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Amount removed from or added to balance.</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>All</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Today</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>This week</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>This month</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Last month</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>This year</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Range...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Received with</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Sent to</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>To yourself</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Mined</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Other</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Enter address or label to search</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Min amount</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Copy address</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Copy label</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Edit label</translation>
    </message>
    <message>
        <source>Export Transaction Data</source>
        <translation>Export Transaction Data</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Comma separated file (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Confirmed</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Address</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Amount</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Error exporting</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>Could not write to file %1.</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Range:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>to</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Sending...</source>
        <translation>Sending...</translation>
    </message>
</context>
<context>
    <name>WindowOptionsPage</name>
    </context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Usage:</source>
        <translation>Usage:</translation>
    </message>
    <message>
        <source>List commands</source>
        <translation>List commands
</translation>
    </message>
    <message>
        <source>Get help for a command</source>
        <translation>Get help for a command
</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Options:
</translation>
    </message>
    <message>
        <source>Specify pid file (default: paycoind.pid)</source>
        <translation>Specify pid file (default: paycoind.pid)
</translation>
    </message>
    <message>
        <source>Generate coins</source>
        <translation>Generate coins
</translation>
    </message>
    <message>
        <source>Don't generate coins</source>
        <translation>Don't generate coins
</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Specify data directory
</translation>
    </message>
    <message>
        <source>Specify connection timeout (in milliseconds)</source>
        <translation>Specify connection timeout (in milliseconds)
</translation>
    </message>
    <message>
        <source>Connect only to the specified node</source>
        <translation>Connect only to the specified node
</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Run in the background as a daemon and accept commands
</translation>
    </message>
    <message>
        <source>Use the test network</source>
        <translation>Use the test network
</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Username for JSON-RPC connections
</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Password for JSON-RPC connections
</translation>
    </message>
    <message>
        <source>Allow JSON-RPC connections from specified IP address</source>
        <translation>Allow JSON-RPC connections from specified IP address
</translation>
    </message>
    <message>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</source>
        <translation>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)
</translation>
    </message>
    <message>
        <source>Set key pool size to &lt;n&gt; (default: 100)</source>
        <translation>Set key pool size to &lt;n&gt; (default: 100)
</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Rescan the block chain for missing wallet transactions
</translation>
    </message>
    <message>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>Use OpenSSL (https) for JSON-RPC connections
</translation>
    </message>
    <message>
        <source>Server certificate file (default: server.cert)</source>
        <translation>Server certificate file (default: server.cert)
</translation>
    </message>
    <message>
        <source>Server private key (default: server.pem)</source>
        <translation>Server private key (default: server.pem)
</translation>
    </message>
    <message>
        <source>Acceptable ciphers (default: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</source>
        <translation>Acceptable ciphers (default: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)
</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Loading addresses...</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Loading block index...</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Loading wallet...</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Rescanning...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Done loading</translation>
    </message>
    <message>
        <source>Warning: -paytxfee is set very high.  This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Warning: -paytxfee is set very high.  This is the transaction fee you will pay if you send a transaction.</translation>
    </message>
    <message>
        <source>Error: Transaction creation failed  </source>
        <translation>Error: Transaction creation failed  </translation>
    </message>
    <message>
        <source>Sending...</source>
        <translation>Sending...</translation>
    </message>
    <message>
        <source>Error: The transaction was rejected.  This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Error: The transaction was rejected.  This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</translation>
    </message>
    </context>
</TS>