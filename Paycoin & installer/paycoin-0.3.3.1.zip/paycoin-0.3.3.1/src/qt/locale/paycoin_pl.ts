<TS language="pl" version="2.0">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>AboutDialog</name>
    </context>
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Address Book</source>
        <translation>Adresy</translation>
    </message>
    <message>
        <source>Double-click to edit address or label</source>
        <translation>Kliknij dwukrotnie, aby edytować adres lub etykietę</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Utwórz nowy adres</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Skopiuj aktualnie wybrany adres do schowka</translation>
    </message>
    <message>
        <source>Show &amp;QR Code</source>
        <translation>Pokaż Kod &amp;QR</translation>
    </message>
    <message>
        <source>Sign a message to prove you own this address</source>
        <translation>Podpisz wiadomość aby dowieść, że ten adres jest twój</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>Podpi&amp;sz Wiadomość</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list. Only sending addresses can be deleted.</source>
        <translation>Usuń aktualnie wybrany adres z listy. Tylko adresy nadawcze mogą być usunięte.</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Usuń</translation>
    </message>
    <message>
        <source>Export Address Book Data</source>
        <translation>Eksportuj książkę adresową</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>CSV (rozdzielany przecinkami)</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Błąd podczas eksportowania</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>Błąd zapisu do pliku %1.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Etykieta</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adres</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(bez etykiety)</translation>
    </message>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Enter passphrase</source>
        <translation>Wpisz hasło</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Nowe hasło</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Powtórz nowe hasło</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Wprowadź nowe hasło dla portfela.&lt;br/&gt;Proszę użyć hasła składającego się z &lt;b&gt;10 lub więcej losowych znaków&lt;/b&gt; lub &lt;b&gt;ośmiu lub więcej słów&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Zaszyfruj portfel</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Ta operacja wymaga hasła do portfela ażeby odblokować portfel.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Odblokuj portfel</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Ta operacja wymaga hasła do portfela ażeby odszyfrować portfel.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Odszyfruj portfel</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Zmień hasło</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Potwierdź szyfrowanie portfela</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Portfel zaszyfrowany</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on.</source>
        <translation>Ostrzeżenie: Caps Lock jest włączony.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Szyfrowanie portfela nie powiodło się</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Szyfrowanie portfela nie powiodło się z powodu wewnętrznego błędu. Twój portfel nie został zaszyfrowany.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>Podane hasła nie są takie same.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Odblokowanie portfela nie powiodło się</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Wprowadzone hasło do odszyfrowania portfela jest niepoprawne.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Odszyfrowywanie portfela nie powiodło się</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Hasło do portfela zostało pomyślnie zmienione.</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Amount:</source>
        <translation>Kwota:</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Kwota</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adres</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Potwierdzony</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopiuj adres</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopiuj etykietę</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopiuj kwotę</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(bez etykiety)</translation>
    </message>
    </context>
<context>
    <name>DisplayOptionsPage</name>
    <message>
        <source>&amp;Unit to show amounts in: </source>
        <translation>&amp;Jednostka pokazywana przy kwocie:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface, and when sending coins</source>
        <translation>Wybierz podział jednostki pokazywany w interfejsie  oraz podczas wysyłania monet</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Edytuj adres</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Etykieta</translation>
    </message>
    <message>
        <source>The label associated with this address book entry</source>
        <translation>Etykieta skojarzona z tym wpisem w książce adresowej</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Adres</translation>
    </message>
    <message>
        <source>The address associated with this address book entry. This can only be modified for sending addresses.</source>
        <translation>Ten adres jest skojarzony z wpisem w książce adresowej. Może być zmodyfikowany jedynie dla adresów wysyłających.</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Nowy adres odbiorczy</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Nowy adres wysyłania</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Edytuj adres odbioru</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Edytuj adres wysyłania</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book.</source>
        <translation>Wprowadzony adres "%1" już istnieje w książce adresowej.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Nie można było odblokować portfela.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Tworzenie nowego klucza nie powiodło się.</translation>
    </message>
</context>
<context>
    <name>GUIUtil::HelpMessageBox</name>
    </context>
<context>
    <name>MainOptionsPage</name>
    </context>
<context>
    <name>MintingTableModel</name>
    <message>
        <source>Address</source>
        <translation>Adres</translation>
    </message>
    </context>
<context>
    <name>MintingView</name>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>CSV (rozdzielany przecinkami)</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adres</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Błąd podczas eksportowania</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>Błąd zapisu do pliku %1.</translation>
    </message>
    </context>
<context>
    <name>MultisigAddressEntry</name>
    <message>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Choose address from address book</source>
        <translation>Wybierz adres z książki adresowej</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etykieta:</translation>
    </message>
</context>
<context>
    <name>MultisigDialog</name>
    <message>
        <source>Clear all</source>
        <translation>Wyczyść wszystko</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Wklej adres ze schowka</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    </context>
<context>
    <name>MultisigInputEntry</name>
    <message>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
</context>
<context>
    <name>NetworkOptionsPage</name>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Opcje</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Saldo:</translation>
    </message>
    <message>
        <source>Number of transactions:</source>
        <translation>Liczba transakcji:</translation>
    </message>
    <message>
        <source>Unconfirmed:</source>
        <translation>Niepotwierdzony:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;Ostatnie transakcje&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Your current balance</source>
        <translation>Twoje obecne saldo</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the current balance</source>
        <translation>Suma transakcji, które nie zostały jeszcze potwierdzone, i które nie zostały wliczone do twojego obecnego salda</translation>
    </message>
    <message>
        <source>Total number of transactions in wallet</source>
        <translation>Całkowita liczba transakcji w portfelu</translation>
    </message>
    </context>
<context>
    <name>QRCodeDialog</name>
    <message>
        <source>QR Code</source>
        <translation>Kod QR</translation>
    </message>
    <message>
        <source>Request Payment</source>
        <translation>Prośba o płatność</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Kwota:</translation>
    </message>
    <message>
        <source>Label:</source>
        <translation>Etykieta:</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Wiadomość:</translation>
    </message>
    <message>
        <source>&amp;Save As...</source>
        <translation>Zapi&amp;sz jako...</translation>
    </message>
    </context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Wyślij płatność</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Kwota:</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Wyślij do wielu odbiorców na raz</translation>
    </message>
    <message>
        <source>Remove all transaction fields</source>
        <translation>Wyczyść wszystkie pola transakcji</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Saldo:</translation>
    </message>
    <message>
        <source>123.456 BTC</source>
        <translation>123.456 BTC</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Potwierdź akcję wysyłania</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>Wy&amp;syłka</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopiuj kwotę</translation>
    </message>
    <message>
        <source>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; do %2 (%3)</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Potwierdź wysyłanie monet</translation>
    </message>
    <message>
        <source>Are you sure you want to send %1?</source>
        <translation>Czy na pewno chcesz wysłać %1?</translation>
    </message>
    <message>
        <source> and </source>
        <translation> i </translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(bez etykiety)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <source>A&amp;mount:</source>
        <translation>Su&amp;ma:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>Płać &amp;Do:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Wprowadź etykietę dla tego adresu by dodać go do książki adresowej</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Etykieta:</translation>
    </message>
    <message>
        <source>Choose address from address book</source>
        <translation>Wybierz adres z książki adresowej</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Wklej adres ze schowka</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this recipient</source>
        <translation>Usuń tego odbiorce</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>&amp;Sign Message</source>
        <translation>Podpi&amp;sz Wiadomość</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Wklej adres ze schowka</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>Otwórz do %1</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/niezatwierdzone</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 potwierdzeń</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Kwota</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>, nie został jeszcze pomyślnie wyemitowany</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>nieznany</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>Szczegóły transakcji</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Ten panel pokazuje szczegółowy opis transakcji</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adres</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Kwota</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n block(s)</source>
        <translation><numerusform>Otwórz dla %n bloku</numerusform><numerusform>Otwórz dla %n bloków</numerusform><numerusform>Otwórz dla %n bloków</numerusform></translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Otwórz do %1</translation>
    </message>
    <message>
        <source>Offline (%1 confirmations)</source>
        <translation>Offline (%1 potwierdzeń)</translation>
    </message>
    <message>
        <source>Unconfirmed (%1 of %2 confirmations)</source>
        <translation>Niezatwierdzony (%1 z %2 potwierdzeń)</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Zatwierdzony (%1 potwierdzeń)</translation>
    </message>
    <message numerus="yes">
        <source>Mined balance will be available in %n more blocks</source>
        <translation><numerusform>Wydobyta kwota będzie dostępna za %n blok</numerusform><numerusform>Wydobyta kwota będzie dostępna za %n bloków</numerusform><numerusform>Wydobyta kwota będzie dostępna za %n bloki</numerusform></translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Ten blok nie został odebrany przez jakikolwiek inny węzeł i prawdopodobnie nie zostanie zaakceptowany!</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Wygenerowano ale nie zaakceptowano</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Otrzymane przez</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Odebrano od</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Wysłano do</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Płatność do siebie</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Wydobyto</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(brak)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Status transakcji. Najedź na pole, aby zobaczyć liczbę potwierdzeń.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Data i czas odebrania transakcji.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Rodzaj transakcji.</translation>
    </message>
    <message>
        <source>Destination address of transaction.</source>
        <translation>Adres docelowy transakcji.</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Kwota usunięta z lub dodana do konta.</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Wszystko</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Dzisiaj</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>W tym tygodniu</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>W tym miesiącu</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>W zeszłym miesiącu</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>W tym roku</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Zakres...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Otrzymane przez</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Wysłano do</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>Do siebie</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Wydobyto</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Inne</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Wprowadź adres albo etykietę żeby wyszukać</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Min suma</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Kopiuj adres</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Kopiuj etykietę</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Kopiuj kwotę</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Edytuj etykietę</translation>
    </message>
    <message>
        <source>Export Transaction Data</source>
        <translation>Eksportuj Dane Transakcyjne</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>CSV (rozdzielany przecinkami)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Potwierdzony</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etykieta</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adres</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Kwota</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Błąd podczas eksportowania</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>Błąd zapisu do pliku %1.</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Zakres:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>do</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Sending...</source>
        <translation>Wysyłanie...</translation>
    </message>
</context>
<context>
    <name>WindowOptionsPage</name>
    </context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Error: Transaction creation failed  </source>
        <translation>Błąd: Tworzenie transakcji nie powiodło się  </translation>
    </message>
    <message>
        <source>Sending...</source>
        <translation>Wysyłanie...</translation>
    </message>
    </context>
</TS>