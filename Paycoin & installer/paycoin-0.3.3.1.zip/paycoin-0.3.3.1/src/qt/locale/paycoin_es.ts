<TS language="es" version="2.0">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>AboutDialog</name>
    </context>
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Address Book</source>
        <translation>Guia de direcciones</translation>
    </message>
    <message>
        <source>Double-click to edit address or label</source>
        <translation>Haz doble click para editar una dirección o etiqueta</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Crea una nueva dirección</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copia la dirección seleccionada al portapapeles</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list. Only sending addresses can be deleted.</source>
        <translation>Borra la dirección seleccionada de la lista. Solo las direcciónes de envio se pueden borrar.</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>Bo&amp;rrar</translation>
    </message>
    <message>
        <source>Export Address Book Data</source>
        <translation>Exporta datos de la Guia de direcciones</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Archivos separados por coma (*.csv)</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Error exportando</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>No se pudo escribir en el archivo %1.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Dirección</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(sin etiqueta)</translation>
    </message>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Enter passphrase</source>
        <translation>Introduce contraseña actual      </translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Nueva contraseña</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Repite nueva contraseña:</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Introduce la nueva contraseña de cartera.&lt;br/&gt;Por favor utiliza un contraseña &lt;b&gt;de 10 o mas caracteres aleatorios&lt;/b&gt;, u &lt;b&gt;ocho o mas palabras&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Encriptar cartera</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Esta operación necesita la contraseña para desbloquear la cartera.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Desbloquea cartera</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Esta operación necesita la contraseña para decriptar la cartera.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Decriptar cartera</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Cambia contraseña</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Confirma la encriptación de cartera</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Cartera encriptada</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Encriptación de cartera fallida</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Encriptación de cartera fallida debido a un error interno. Tu cartera no ha sido encriptada.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>Las contraseñas no coinciden.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Desbloqueo de cartera fallido</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>La contraseña introducida para decriptar la cartera es incorrecta.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Decriptación de cartera fallida</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>La contraseña de cartera ha sido cambiada con exit.</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Vista general</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Muestra una vista general de cartera</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transacciónes</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Visiona el historial de transacciónes</translation>
    </message>
    <message>
        <source>&amp;Address Book</source>
        <translation>&amp;Guia de direcciónes</translation>
    </message>
    <message>
        <source>Edit the list of stored addresses and labels</source>
        <translation>Edita la lista de las direcciónes y etiquetas almacenada</translation>
    </message>
    <message>
        <source>&amp;Receive coins</source>
        <translation>&amp;Recibe monedas</translation>
    </message>
    <message>
        <source>Show the list of addresses for receiving payments</source>
        <translation>Muestra la lista de direcciónes utilizadas para recibir pagos</translation>
    </message>
    <message>
        <source>&amp;Send coins</source>
        <translation>&amp;Envia monedas</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Salir</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Salir de la aplicación</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Opciones</translation>
    </message>
    <message>
        <source>&amp;Export...</source>
        <translation>&amp;Exporta...</translation>
    </message>
    <message>
        <source>Encrypt or decrypt wallet</source>
        <translation>Encriptar o decriptar cartera</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Cambiar la contraseña utilizada para la encriptación de cartera</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Archivo</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Configuración</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Ayuda</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Barra de pestañas</translation>
    </message>
    <message>
        <source>Actions toolbar</source>
        <translation>Barra de acciónes</translation>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Sincronizando con la red...</translation>
    </message>
    <message>
        <source>Downloaded %1 blocks of transaction history.</source>
        <translation>Se han bajado %1 bloques de historial.</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Actualizado</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Recuperando...</translation>
    </message>
    <message>
        <source>Last received block was generated %1.</source>
        <translation>El ultimo bloque recibido fue generado %1.</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Transacción enviada</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Transacción entrante</translation>
    </message>
    <message>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Fecha: %1
Cantidad: %2
Tipo: %3
Dirección: %4</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>La cartera esta &lt;b&gt;encriptada&lt;/b&gt; y actualmente &lt;b&gt;desbloqueda&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>La cartera esta &lt;b&gt;encriptada&lt;/b&gt; y actualmente &lt;b&gt;bloqueda&lt;/b&gt;</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>0.00 BTC</source>
        <translation>123.456 BTC {0.00 ?}</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>Modo de lista</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Cantidad</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Dirección</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Fecha</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Confirmaciónes</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Confirmado</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Copia dirección</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Copia etiqueta</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(sin etiqueta)</translation>
    </message>
    </context>
<context>
    <name>DisplayOptionsPage</name>
    <message>
        <source>&amp;Unit to show amounts in: </source>
        <translation>&amp;Unidad en la que mostrar cantitades: </translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface, and when sending coins</source>
        <translation>Elige la subdivisión por defecto para mostrar cantidaded en la interfaz cuando se envien monedas</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Editar Dirección</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Etiqueta</translation>
    </message>
    <message>
        <source>The label associated with this address book entry</source>
        <translation>La etiqueta asociada con esta entrada de la guia</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Dirección</translation>
    </message>
    <message>
        <source>The address associated with this address book entry. This can only be modified for sending addresses.</source>
        <translation>La dirección asociada con esta entrada en la guia. Solo puede ser modificada para direcciónes de envío.</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Nueva dirección para recibir</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Nueva dirección para enviar</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Editar dirección de recepción</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Editar dirección de envio</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book.</source>
        <translation>La dirección introducia "%1" ya esta guardada en la guia.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>No se pudo desbloquear la cartera.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>La generación de nueva clave fallida.</translation>
    </message>
</context>
<context>
    <name>GUIUtil::HelpMessageBox</name>
    </context>
<context>
    <name>MainOptionsPage</name>
    </context>
<context>
    <name>MintingTableModel</name>
    <message>
        <source>Address</source>
        <translation>Dirección</translation>
    </message>
    </context>
<context>
    <name>MintingView</name>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Archivos separados por coma (*.csv)</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Dirección</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Error exportando</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>No se pudo escribir en el archivo %1.</translation>
    </message>
    </context>
<context>
    <name>MultisigAddressEntry</name>
    <message>
        <source>Form</source>
        <translation>Envio</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Choose address from address book</source>
        <translation>Elije dirección de la  guia</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    </context>
<context>
    <name>MultisigDialog</name>
    <message>
        <source>Clear all</source>
        <translation>&amp;Borra todos</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Pega dirección desde portapapeles</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    </context>
<context>
    <name>MultisigInputEntry</name>
    <message>
        <source>Form</source>
        <translation>Envio</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
</context>
<context>
    <name>NetworkOptionsPage</name>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Envio</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Balance:</translation>
    </message>
    <message>
        <source>Number of transactions:</source>
        <translation>Numero de movimientos:</translation>
    </message>
    <message>
        <source>Unconfirmed:</source>
        <translation>No confirmado(s):</translation>
    </message>
    <message>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;Movimientos recientes&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Your current balance</source>
        <translation>Tu balance actual</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the current balance</source>
        <translation>El total de las transacciones que faltan por confirmar y que no se cuentan para el total general.</translation>
    </message>
    <message>
        <source>Total number of transactions in wallet</source>
        <translation>El numero total de movimiento en cartera</translation>
    </message>
    </context>
<context>
    <name>QRCodeDialog</name>
    <message>
        <source>Message:</source>
        <translation>Mensaje:</translation>
    </message>
    </context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Envia monedas</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>0.00 BTC</source>
        <translation>123.456 BTC {0.00 ?}</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Envia a multiples destinatarios de una vez</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Balance:</translation>
    </message>
    <message>
        <source>123.456 BTC</source>
        <translation>123.456 BTC</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Confirma el envio</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Envía</translation>
    </message>
    <message>
        <source>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Confirmar el envio de monedas</translation>
    </message>
    <message>
        <source>Are you sure you want to send %1?</source>
        <translation>Estas seguro que quieres enviar %1?</translation>
    </message>
    <message>
        <source> and </source>
        <translation>y</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(sin etiqueta)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>Form</source>
        <translation>Envio</translation>
    </message>
    <message>
        <source>A&amp;mount:</source>
        <translation>Cantidad:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>&amp;Pagar a:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Introduce una etiqueta a esta dirección para añadirla a tu guia</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Etiqueta:</translation>
    </message>
    <message>
        <source>Choose address from address book</source>
        <translation>Elije dirección de la  guia</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Pega dirección desde portapapeles</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this recipient</source>
        <translation>Elimina destinatario</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Pega dirección desde portapapeles</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>Abierto hasta %1</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/no confirmado</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 confirmaciónes</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Fecha</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Cantidad</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>, no ha sido emitido satisfactoriamente todavía</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>desconocido</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>Detalles de transacción</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Esta ventana muestra información detallada sobre la transacción</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Fecha</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Dirección</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Cantidad</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n block(s)</source>
        <translation><numerusform>Abierto por %n bloque</numerusform><numerusform>Abierto por %n bloques</numerusform></translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Abierto hasta %1</translation>
    </message>
    <message>
        <source>Offline (%1 confirmations)</source>
        <translation>Fuera de linea (%1 confirmaciónes)</translation>
    </message>
    <message>
        <source>Unconfirmed (%1 of %2 confirmations)</source>
        <translation>No confirmado (%1 de %2 confirmaciónes)</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Confirmado (%1 confirmaciones)</translation>
    </message>
    <message numerus="yes">
        <source>Mined balance will be available in %n more blocks</source>
        <translation><numerusform>El balance minado estará disponible en %n bloque mas</numerusform><numerusform>El balance minado estará disponible en %n bloques mas</numerusform></translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Este bloque no ha sido recibido por otros nodos y probablemente no sea aceptado !</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Generado pero no acceptado</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Recibido con</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Enviado a</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Pago proprio</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Minado</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(n/a)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Estado de transacción. Pasa el raton sobre este campo para ver el numero de confirmaciónes.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Fecha y hora cuando se recibió la transaccion</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Tipo de transacción.</translation>
    </message>
    <message>
        <source>Destination address of transaction.</source>
        <translation>Dirección de destino para la transacción</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Cantidad restada o añadida al balance</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Todo</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Hoy</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>Esta semana</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>Esta mes</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Mes pasado</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>Este año</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Rango...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Recibido con</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Enviado a</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>A ti mismo</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Minado</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Otra</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Introduce una dirección o etiqueta para  buscar</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Cantidad minima</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Copia dirección</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Copia etiqueta</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Edita etiqueta</translation>
    </message>
    <message>
        <source>Export Transaction Data</source>
        <translation>Exportar datos de transacción</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Archivos separados por coma (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Confirmado</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Fecha</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Dirección</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Cantidad</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Error exporting</source>
        <translation>Error exportando</translation>
    </message>
    <message>
        <source>Could not write to file %1.</source>
        <translation>No se pudo escribir en el archivo %1.</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Rango:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>para</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Sending...</source>
        <translation>Enviando...</translation>
    </message>
</context>
<context>
    <name>WindowOptionsPage</name>
    </context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Usage:</source>
        <translation>Uso:</translation>
    </message>
    <message>
        <source>List commands</source>
        <translation>Muestra comandos
</translation>
    </message>
    <message>
        <source>Get help for a command</source>
        <translation>Recibir ayuda para un comando
</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Opciones:
</translation>
    </message>
    <message>
        <source>Specify pid file (default: paycoind.pid)</source>
        <translation>Especifica archivo pid (predeterminado: Paycoin.pid)
</translation>
    </message>
    <message>
        <source>Generate coins</source>
        <translation>Genera monedas
</translation>
    </message>
    <message>
        <source>Don't generate coins</source>
        <translation>No generar monedas
</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Especifica directorio para los datos
</translation>
    </message>
    <message>
        <source>Specify connection timeout (in milliseconds)</source>
        <translation>Especifica tiempo de espera para conexion (en milisegundos)
</translation>
    </message>
    <message>
        <source>Connect only to the specified node</source>
        <translation>Conecta solo al nodo especificado
</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Correr como demonio y acepta comandos
</translation>
    </message>
    <message>
        <source>Use the test network</source>
        <translation>Usa la red de pruebas
</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Usuario para las conexiones JSON-RPC
</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Contraseña para las conexiones JSON-RPC
</translation>
    </message>
    <message>
        <source>Allow JSON-RPC connections from specified IP address</source>
        <translation>Permite conexiones JSON-RPC desde la dirección IP especificada
</translation>
    </message>
    <message>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</source>
        <translation>Envia comando al nodo situado en &lt;ip&gt; (predeterminado: 127.0.0.1)
</translation>
    </message>
    <message>
        <source>Set key pool size to &lt;n&gt; (default: 100)</source>
        <translation>Ajusta el numero de claves en reserva &lt;n&gt; (predeterminado: 100)
</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Rescanea la cadena de bloques para transacciones perdidas de la cartera
</translation>
    </message>
    <message>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>Usa OpenSSL (https) para las conexiones JSON-RPC
</translation>
    </message>
    <message>
        <source>Server certificate file (default: server.cert)</source>
        <translation>Certificado del servidor (Predeterminado: server.cert)
</translation>
    </message>
    <message>
        <source>Server private key (default: server.pem)</source>
        <translation>Clave privada del servidor (Predeterminado: server.pem)
</translation>
    </message>
    <message>
        <source>Acceptable ciphers (default: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</source>
        <translation>Cifrados aceptados (Predeterminado: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)
</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Cargando direcciónes...</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Cargando el index de bloques...</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Cargando cartera...</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Rescaneando...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Carga completa</translation>
    </message>
    <message>
        <source>Warning: -paytxfee is set very high.  This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Precaución: -paytxfee es muy alta. Esta es la comisión que pagarás si envias una transacción.</translation>
    </message>
    <message>
        <source>Error: Transaction creation failed  </source>
        <translation>Error: La transacción no se pudo crear  </translation>
    </message>
    <message>
        <source>Sending...</source>
        <translation>Enviando...</translation>
    </message>
    <message>
        <source>Error: The transaction was rejected.  This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Error: La transacción fue rechazada. Esto puede haber ocurrido si alguna de las monedas ya estaba gastada o si ha usado una copia de wallet.dat y las monedas se gastaron en la copia pero no se han marcado como gastadas aqui.</translation>
    </message>
    </context>
</TS>